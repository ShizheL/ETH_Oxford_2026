# SkyTrace 项目搭建指南 — 从零开始

## 📁 最终项目结构

```
skytrace/
├── frontend/                    # React 前端
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── components/          # 每一页一个组件
│   │   │   ├── Page1Landing.jsx
│   │   │   ├── Page2Transition.jsx
│   │   │   ├── Page3Chat.jsx
│   │   │   ├── Page4Passport.jsx
│   │   │   ├── Page5Optimizer.jsx
│   │   │   └── Page6About.jsx
│   │   ├── styles/              # 每一页一个CSS
│   │   │   ├── Page1Landing.css
│   │   │   ├── Page2Transition.css
│   │   │   ├── Page3Chat.css
│   │   │   ├── Page4Passport.css
│   │   │   ├── Page5Optimizer.css
│   │   │   └── Page6About.css
│   │   ├── assets/              # 图片等静态资源
│   │   │   └── (放你的图片文件)
│   │   ├── App.jsx              # 主组件，管理页面切换
│   │   ├── App.css              # 全局样式
│   │   └── main.jsx             # 入口文件
│   ├── package.json
│   └── vite.config.js
│
├── backend/                     # Python FastAPI 后端
│   ├── main.py                  # API 入口
│   ├── optimizer.py             # 路线优化逻辑 (Module 2)
│   ├── ef_api.py                # EF + 燃料 API (Module 1)
│   ├── verification.py          # 验证模块 (Module 3)
│   └── requirements.txt
│
└── README.md
```

---

## 第一步：安装必要工具

你需要先安装：

1. **Node.js** (v18+): https://nodejs.org/  
2. **Python** (v3.10+): https://www.python.org/  
3. **VS Code** (推荐编辑器): https://code.visualstudio.com/

验证安装：
```bash
node --version    # 应显示 v18.x 或更高
npm --version     # 应显示 9.x 或更高
python --version  # 应显示 3.10 或更高
```

---

## 第二步：创建 React 前端

### 2.1 用 Vite 初始化项目

打开终端，`cd` 到你想放项目的文件夹，然后：

```bash
npm create vite@latest frontend -- --template react
cd frontend
npm install
```

### 2.2 安装前端依赖

```bash
npm install react-leaflet leaflet
```

### 2.3 替换文件

删除 `src/` 下所有默认文件，然后按下面的内容创建新文件。

---

## 第三步：创建 Python 后端

### 3.1 初始化后端

```bash
cd ..
mkdir backend
cd backend
python -m venv venv

# Mac/Linux:
source venv/bin/activate
# Windows:
venv\Scripts\activate

pip install fastapi uvicorn httpx python-dotenv
pip freeze > requirements.txt
```

### 3.2 启动后端

```bash
cd backend
source venv/bin/activate  # 或 Windows: venv\Scripts\activate
uvicorn main:app --reload --port 8000
```

### 3.3 启动前端

新开一个终端窗口：
```bash
cd frontend
npm run dev
```

浏览器访问 http://localhost:5173 即可看到前端。

---

## 第四步：各文件的来源说明

| 文件 | 对应原HTML的哪部分 | 需要做什么 |
|------|---------------------|-----------|
| `Page1Landing.jsx` + `.css` | `#page1` 的 HTML + CSS | 从HTML中提取并转成JSX语法 |
| `Page2Transition.jsx` + `.css` | `#page2` 的 HTML + CSS | 同上 |
| `Page3Chat.jsx` + `.css` | `#page3` + chatbot JS逻辑 | 转JSX + 把OpenAI调用改成Anthropic |
| `Page4Passport.jsx` + `.css` | `#page4` + passport逻辑 | 转JSX |
| `Page5Optimizer.jsx` + `.css` | `#page5` + map/optimize JS | 转JSX + 用react-leaflet |
| `Page6About.jsx` + `.css` | `#page6` 的 HTML + CSS | 转JSX |
| `App.jsx` | 全局 `goToPage()` 逻辑 | 用React state管理页面切换 |
| `backend/main.py` | 原HTML中 `fetch()` 调用的API | FastAPI路由 |

---

## 第五步：核心概念 — HTML → JSX 转换规则

记住以下几条规则：

| HTML | JSX |
|------|-----|
| `class="xxx"` | `className="xxx"` |
| `for="xxx"` | `htmlFor="xxx"` |
| `onclick="fn()"` | `onClick={fn}` |
| `style="color: red"` | `style={{ color: 'red' }}` |
| `<input>` (不闭合) | `<input />` (必须闭合) |
| `<br>` | `<br />` |
| `<hr>` | `<hr />` |

---

## 第六步：关键改动说明

### 6.1 AI 聊天 — 从 OpenAI 改为 Anthropic

原HTML使用了OpenAI API。你应该改用Anthropic Claude API（因为是ETH Oxford Hackathon + Flare相关项目）。

**改动要点**：
- API endpoint 从 `api.openai.com` → `api.anthropic.com`
- 请求格式不同（见 `Page3Chat.jsx` 中的注释）
- 或者：通过你的 Python 后端代理 AI 调用（更安全，不暴露API key）

### 6.2 地图 — 从原生Leaflet改为 react-leaflet

原HTML直接用 `L.map()` 创建地图。在React中，我们用 `react-leaflet` 组件：
- `<MapContainer>` 替代 `L.map()`
- `<TileLayer>` 替代 `L.tileLayer()`
- `<Polyline>` 替代 `L.polyline()`
- `<Marker>` 替代 `L.marker()`

### 6.3 状态管理

原HTML用全局变量 (`let flightData = {...}`)。React中用 `useState`：
```jsx
const [flightData, setFlightData] = useState({
  departure: '',
  destination: '',
  // ...
});
```

### 6.4 页面切换

原HTML用 `goToPage(n)` + CSS `.active`。React中用状态：
```jsx
const [currentPage, setCurrentPage] = useState(1);
// 在App.jsx中根据currentPage渲染不同组件
```

---

## 第七步：开发顺序建议

1. **先搭骨架**：创建所有文件，每个页面组件先写一个简单的 `<div>Page X</div>`
2. **逐页迁移**：按 P1 → P2 → P3 → P4 → P5 → P6 的顺序，一页一页把HTML转成JSX
3. **接通API**：先用mock数据让UI跑通，再接真实的后端API
4. **最后美化**：微调样式、添加动画

---

## 附：常用命令速查

```bash
# 前端
cd frontend
npm run dev          # 启动开发服务器
npm run build        # 打包生产版本

# 后端
cd backend
source venv/bin/activate
uvicorn main:app --reload --port 8000

# 同时运行（两个终端窗口）
# 终端1: 前端 → localhost:5173
# 终端2: 后端 → localhost:8000
```
